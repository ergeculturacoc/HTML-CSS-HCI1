// Cake Data
const cakes = [
    {
        id: 1,
        name: "Strawberry Dream",
        price: 350.00,
        description: "Fresh strawberries with light cream and vanilla sponge.",
        image: "cake1.jpg"
    },
    {
        id: 2,
        name: "Classic White Wedding",
        price: 450.00,
        description: "Elegant white frosting with delicate floral accents.",
        image: "cake 2.jpg"
    },
    {
        id: 3,
        name: "Berry Bliss",
        price: 380.00,
        description: "A medley of fresh berries on a rich chocolate base.",
        image: "cake3.jpg"
    },
    {
        id: 4,
        name: "Minimalist Elegance",
        price: 520.00,
        description: "Sleek, modern design with a smooth buttercream finish.",
        image: "cake4.jpg"
    }
];

// State Management
let cart = JSON.parse(localStorage.getItem('cakeCart')) || [];
let orders = JSON.parse(localStorage.getItem('cakeOrders')) || [];

// DOM Elements
const cakeMenu = document.getElementById('cake-menu');
const cartBtn = document.getElementById('cart-btn');
const cartSidebar = document.getElementById('cart-sidebar');
const closeCart = document.getElementById('close-cart');
const cartItemsContainer = document.getElementById('cart-items');
const cartTotalPrice = document.getElementById('cart-total-price');
const cartCount = document.getElementById('cart-count');
const checkoutBtn = document.getElementById('checkout-btn');
const checkoutModal = document.getElementById('checkout-modal');
const closeModal = document.querySelector('.close-modal');
const checkoutForm = document.getElementById('checkout-form');

// Customizer Elements
const customFlavor = document.getElementById('custom-flavor');
const customSizeRadios = document.getElementsByName('size');
const customIcing = document.getElementById('custom-icing');
const customMessage = document.getElementById('custom-message');
const addCustomBtn = document.getElementById('add-custom-btn');
const previewFlavor = document.getElementById('prev-flavor');
const previewSize = document.getElementById('prev-size');
const previewMessage = document.getElementById('prev-message');
const previewPrice = document.getElementById('prev-price');
const previewVisual = document.getElementById('preview-visual');
const cakeLayer = document.querySelector('.cake-layer');

window.addEventListener('DOMContentLoaded', () => {
    renderMenu();
    updateCartUI();
});

// Render Cake Menu
function renderMenu() {
    cakeMenu.innerHTML = cakes.map(cake => `
        <div class="cake-card fade-in">
            <img src="${cake.image}" alt="${cake.name}">
            <h3>${cake.name}</h3>
            <p class="price">₱${cake.price.toFixed(2)}</p>
            <p>${cake.description}</p>
            <button class="btn btn-primary" onclick="addToCart(${cake.id})">Add to Cart</button>
        </div>
    `).join('');
}

// Cart Functions
function addToCart(id) {
    const cake = cakes.find(c => c.id === id);
    const existingItem = cart.find(item => item.id === id && !item.isCustom);
    
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({ ...cake, quantity: 1, isCustom: false });
    }
    
    saveCart();
    updateCartUI();
    openCartSidebar();
}

function addCustomToCart() {
    const flavor = customFlavor.value;
    const size = Array.from(customSizeRadios).find(r => r.checked).value;
    const icing = customIcing.value;
    const message = customMessage.value || "None";
    const price = parseFloat(previewPrice.innerText);
    
    const customCake = {
        id: Date.now(),
        name: `Custom ${flavor} Cake (${size}")`,
        price: price,
        description: `Icing: ${icing}, Message: ${message}`,
        image: "costumized.jpg",
        quantity: 1,
        isCustom: true,
        details: { flavor, size, icing, message }
    };
    
    cart.push(customCake);
    saveCart();
    updateCartUI();
    openCartSidebar();
}

function removeFromCart(index) {
    cart.splice(index, 1);
    saveCart();
    updateCartUI();
}

function updateQuantity(index, delta) {
    cart[index].quantity += delta;
    if (cart[index].quantity <= 0) {
        cart.splice(index, 1);
    }
    saveCart();
    updateCartUI();
}

function saveCart() {
    localStorage.setItem('cakeCart', JSON.stringify(cart));
}

function updateCartUI() {
    cartCount.innerText = cart.reduce((sum, item) => sum + item.quantity, 0);
    
    if (cart.length === 0) {
        cartItemsContainer.innerHTML = '<p style="text-align:center; margin-top:20px;">Your cart is empty.</p>';
        cartTotalPrice.innerText = '₱0.00';
        return;
    }
    
    cartItemsContainer.innerHTML = cart.map((item, index) => `
        <div class="cart-item">
            <img src="${item.image}" alt="${item.name}">
            <div class="cart-item-info">
                <h4>${item.name}</h4>
                <p>₱${item.price.toFixed(2)}</p>
                <div class="cart-item-qty">
                    <button onclick="updateQuantity(${index}, -1)">-</button>
                    <span>${item.quantity}</span>
                    <button onclick="updateQuantity(${index}, 1)">+</button>
                </div>
            </div>
            <i class="fas fa-trash" onclick="removeFromCart(${index})" style="cursor:pointer; color:#ff9aa8;"></i>
        </div>
    `).join('');
    
    const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    cartTotalPrice.innerText = `₱${total.toFixed(2)}`;
}

// Sidebar & Modal Toggles
function openCartSidebar() { cartSidebar.classList.add('active'); }
function closeCartSidebar() { cartSidebar.classList.remove('active'); }

cartBtn.onclick = openCartSidebar;
closeCart.onclick = closeCartSidebar;

checkoutBtn.onclick = () => {
    if (cart.length === 0) {
        alert("Your cart is empty!");
        return;
    }
    closeCartSidebar();
    renderCheckoutSummary();
    checkoutModal.style.display = 'flex';
};

closeModal.onclick = () => checkoutModal.style.display = 'none';
window.onclick = (e) => { if (e.target == checkoutModal) checkoutModal.style.display = 'none'; };

// Customizer Logic
function updatePreview() {
    const flavor = customFlavor.value;
    const size = Array.from(customSizeRadios).find(r => r.checked).value;
    const message = customMessage.value || "None";
    const icing = customIcing.value;
    
    let basePrice = 250;
    if (size === "8") basePrice = 450;
    if (size === "10") basePrice = 550;
    
    previewFlavor.innerText = flavor;
    previewSize.innerText = size + '"';
    previewMessage.innerText = message;
    previewPrice.innerText = basePrice.toFixed(2);
    cakeLayer.style.backgroundColor = icing;
}

Array.from(customSizeRadios).forEach(r => 
    r.addEventListener('change', updatePreview)
);

[customFlavor, customIcing, customMessage].forEach(el => 
    el.addEventListener('input', updatePreview)
);

addCustomBtn.onclick = addCustomToCart;
// Checkout Logic
function renderCheckoutSummary() {
    const summary = document.getElementById('checkout-summary');

    if (!summary) return;

    if (cart.length === 0) {
        summary.innerHTML = `<p style="text-align:center;">No items in checkout.</p>`;
        return;
    }

    let total = 0;

    const itemsHTML = cart.map(item => {
        const itemTotal = item.price * item.quantity;
        total += itemTotal;

        return `
            <div style="display:flex; justify-content:space-between; margin-bottom:5px;">
                <span>${item.name} x ${item.quantity}</span>
                <span>₱${itemTotal.toFixed(2)}</span>
            </div>
        `;
    }).join('');

    summary.innerHTML = `
        ${itemsHTML}
        <div style="border-top:1px solid #ddd; margin-top:10px; padding-top:10px; font-weight:700; display:flex; justify-content:space-between;">
            <span>Total</span>
            <span>₱${total.toFixed(2)}</span>
        </div>
    `;
}

checkoutForm.onsubmit = (e) => {
    e.preventDefault();

    if (cart.length === 0) {
        alert("Your cart is empty!");
        return;
    }

    const order = {
        id: 'ORD-' + Math.floor(Math.random() * 100000),

        customer: document.getElementById('name').value,
        email: document.getElementById('email').value,
        phone: document.getElementById('phone').value,
        address: document.getElementById('address').value,
        deliveryDate: document.getElementById('delivery-date').value,

        items: cart.map(item => `${item.name} (x${item.quantity})`).join(', '),

        total: cart.reduce((sum, item) => sum + (item.price * item.quantity), 0).toFixed(2),

        date: new Date().toLocaleDateString(),
        status: 'Pending'
    };

    orders.push(order);
    localStorage.setItem('cakeOrders', JSON.stringify(orders));

    cart = [];
    saveCart();
    updateCartUI();

    checkoutModal.style.display = 'none';
    checkoutForm.reset();

    alert("Thank you! Your order has been placed successfully.");
};

// Mobile Menu Toggle
const mobileMenu = document.getElementById('mobile-menu');
const navLinks = document.querySelector('.nav-links');

mobileMenu.onclick = () => {
    navLinks.style.display = navLinks.style.display === 'flex' ? 'none' : 'flex';
    if (navLinks.style.display === 'flex') {
        navLinks.style.flexDirection = 'column';
        navLinks.style.position = 'absolute';
        navLinks.style.top = '70px';
        navLinks.style.left = '0';
        navLinks.style.width = '100%';
        navLinks.style.background = 'white';
        navLinks.style.padding = '20px';
        navLinks.style.boxShadow = '0 5px 10px rgba(0,0,0,0.1)';
    }
};
