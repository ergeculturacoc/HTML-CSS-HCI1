/* LOGIN */
function login() {
    let u = document.getElementById("username").value;
    let p = document.getElementById("password").value;

    if (u === "admin" && p === "1234") {
        document.getElementById("loginBox").style.display = "none";
        document.getElementById("dashboard").style.display = "block";

        loadOrders();
        loadCakes();
    } else {
        alert("Wrong login");
    }
}

function logout() {
    location.reload();
}


/* NAVIGATION */
function showOrders() {
    document.getElementById("home").style.display = "none";
    document.getElementById("ordersPage").classList.remove("hidden");
}

function showMenu() {
    document.getElementById("home").style.display = "none";
    document.getElementById("menuPage").classList.remove("hidden");
}

function backHome() {
    document.getElementById("home").style.display = "block";
    document.getElementById("ordersPage").classList.add("hidden");
    document.getElementById("menuPage").classList.add("hidden");
}


/* ORDERS */
function loadOrders() {
    let orders = JSON.parse(localStorage.getItem("cakeOrders")) || [];
    let table = document.getElementById("ordersTable");

    if (orders.length === 0) {
        table.innerHTML = "<tr><td colspan='6'>No Orders</td></tr>";
        return;
    }

    table.innerHTML = orders.map((o, i) => `
        <tr>
            <td>${o.id}</td>
            <td>${o.customer}</td>
            <td>${o.items}</td>
            <td>${o.total}</td>
            <td>
                <span class="${o.status === "Pending" ? "pending" : "success"}">
                    ${o.status}
                </span>
            </td>
            <td>
                <button class="action-btn" onclick="completeOrder(${i})">
                    Mark Successful
                </button>
            </td>
        </tr>
    `).join("");
}

function completeOrder(i) {
    let orders = JSON.parse(localStorage.getItem("cakeOrders"));
    orders[i].status = "Successful";

    localStorage.setItem("cakeOrders", JSON.stringify(orders));

    loadOrders();
}


/* CAKES */
function loadCakes() {
    let cakes = JSON.parse(localStorage.getItem("cakes")) || [];
    let list = document.getElementById("cakeList");

    list.innerHTML = cakes.map((c, i) => `
        <div class="cake">
            <img src="${c.image}">
            <h4>${c.name}</h4>
            <p>₱${Number(c.price).toFixed(2)}</p>

            <button onclick="deleteCake(${i})" class="delete-btn">
                Remove
            </button>
        </div>
    `).join("");
}


function addCake() {

    let cakes = JSON.parse(localStorage.getItem("cakes")) || [];

    let priceInput = document.getElementById("cakePrice").value;

    let newCake = {

        id: Date.now(),

        name: document.getElementById("cakeName").value,

        // always save correct decimal format
        price: Number(priceInput).toFixed(2),

        image: document.getElementById("cakeImg").value
    };

    cakes.push(newCake);

    localStorage.setItem("cakes", JSON.stringify(cakes));

    alert("Cake Added");

    loadCakes();

    document.getElementById("cakeName").value = "";
    document.getElementById("cakePrice").value = "";
    document.getElementById("cakeImg").value = "";
    
}
function deleteCake(index) {
    let cakes = JSON.parse(localStorage.getItem("cakes")) || [];
    cakes.splice(index, 1); // tangtangon ang cake sa array
    localStorage.setItem("cakes", JSON.stringify(cakes)); // i-update ang localStorage
    loadCakes(); // i-refresh ang list sa cakes
}


/* DEFAULT CAKES */
if (!localStorage.getItem("cakes")) {

    let defaultCakes = [

        {
            id: 1,
            name: "Strawberry Dream",
            price: 350.00,
            image: "cake1.jpg"
        },

        {
            id: 2,
            name: "Classic White Wedding",
            price: 450.00,
            image: "cake 2.jpg"
        }

    ];

    localStorage.setItem("cakes", JSON.stringify(defaultCakes));
}